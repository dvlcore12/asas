"""
Flask application factory.
"""
from flask import Flask, request, render_template, redirect, url_for
from flask_cors import CORS
from config import get_config
from app.models import db
from app.services import mail
from app.views import auth_bp, totp_bp, password_bp, oauth_bp
from logging_config import setup_logging
import logging

logger = logging.getLogger('rentit')


def create_app(config=None):
    """
    Create and configure Flask application.
    
    Args:
        config: Configuration object (optional)
        
    Returns:
        Flask application instance
    """
    # Setup logging first
    setup_logging()
    
    app = Flask(__name__)
    
    # Load configuration
    if config is None:
        config = get_config()
    
    app.config.from_object(config)
    
    logger.info(f"Creating Flask app with {config.__class__.__name__} config")
    
    # Initialize extensions
    db.init_app(app)
    mail.init_app(app)
    CORS(app)
    
    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(totp_bp)
    app.register_blueprint(password_bp)
    app.register_blueprint(oauth_bp)
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 errors."""
        logger.warning(f"404 error: {request.path}")
        return {'error': 'Not found'}, 404
    
    @app.errorhandler(400)
    def bad_request(error):
        """Handle 400 errors."""
        logger.warning(f"400 error: {str(error)}")
        return {'error': 'Bad request'}, 400
    
    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors."""
        logger.error(f"500 error: {str(error)}")
        return {'error': 'Internal server error'}, 500
    
    # Create database tables
    with app.app_context():
        db.create_all()
        logger.info("Database tables created")
    
    # Health check endpoint
    @app.route('/health', methods=['GET'])
    def health():
        """Health check endpoint."""
        return {'status': 'ok'}, 200
    
    # HTML Pages
    @app.route('/', methods=['GET'])
    def index():
        """Home page."""
        if request.args.get('token'):
            return redirect(url_for('reset_password_page'))
        return redirect(url_for('login_page'))
    
    @app.route('/login', methods=['GET'])
    def login_page():
        """Login page."""
        return render_template('login.html')
    
    @app.route('/register', methods=['GET'])
    def register_page():
        """Registration page."""
        return render_template('register.html')
    
    @app.route('/forgot-password', methods=['GET'])
    def forgot_password_page():
        """Forgot password page."""
        return render_template('forgot_password.html')
    
    @app.route('/reset-password', methods=['GET'])
    def reset_password_page():
        """Reset password page."""
        return render_template('reset_password.html')
    
    @app.route('/totp-verify', methods=['GET'])
    def totp_verify_page():
        """TOTP verification page."""
        return render_template('totp_verify.html')
    
    @app.route('/totp-verify-email', methods=['GET'])
    def totp_verify_email_page():
        """TOTP email verification page."""
        return render_template('totp_verify_email.html')
    
    @app.route('/totp-setup', methods=['GET'])
    def totp_setup_page():
        """TOTP setup page."""
        return render_template('totp_setup.html')
    
    @app.route('/dashboard', methods=['GET'])
    def dashboard_page():
        """User dashboard."""
        return render_template('dashboard.html')
    
    logger.info("Flask app created successfully")
    
    return app
