"""
Database models for RentIT application.
"""
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
import os

db = SQLAlchemy()


class User(db.Model):
    """User model with authentication support."""
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    username = db.Column(db.String(100), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=True)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    
    # Account status
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    verification_token = db.Column(db.String(255), unique=True, nullable=True)
    verification_token_expires = db.Column(db.DateTime, nullable=True)
    
    # TOTP Settings
    totp_enabled = db.Column(db.Boolean, default=False)
    totp_type = db.Column(db.String(50), default=None)  # 'email' or 'app'
    
    # Google OAuth
    google_id = db.Column(db.String(255), unique=True, nullable=True, index=True)
    google_email = db.Column(db.String(255), nullable=True)
    
    # Password reset
    reset_token = db.Column(db.String(255), unique=True, nullable=True)
    reset_token_expires = db.Column(db.DateTime, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    totp_settings = db.relationship('TOTPSettings', backref='user', uselist=False, cascade='all, delete-orphan')
    refresh_tokens = db.relationship('RefreshToken', backref='user', cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Hash and set password."""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password against hash."""
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'


class TOTPSettings(db.Model):
    """TOTP settings for two-factor authentication."""
    __tablename__ = 'totp_settings'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), unique=True, nullable=False, index=True)
    
    # TOTP secret (encrypted)
    secret = db.Column(db.String(255), nullable=False)
    
    # Backup codes (encrypted, comma-separated)
    backup_codes = db.Column(db.Text, nullable=True)
    
    # TOTP type
    totp_type = db.Column(db.String(50), nullable=False)  # 'email' or 'app'
    
    # Status
    is_verified = db.Column(db.Boolean, default=False)
    verified_at = db.Column(db.DateTime, nullable=True)
    
    # Email TOTP specific
    email_totp_secret = db.Column(db.String(255), nullable=True)  # For temporary email OTP storage
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f'<TOTPSettings {self.user_id}>'


class RefreshToken(db.Model):
    """Refresh tokens for JWT authentication."""
    __tablename__ = 'refresh_tokens'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Token (hashed)
    token_hash = db.Column(db.String(255), unique=True, nullable=False, index=True)
    
    # Token metadata
    user_agent = db.Column(db.String(500), nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    
    # Status
    is_revoked = db.Column(db.Boolean, default=False)
    revoked_at = db.Column(db.DateTime, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    last_used = db.Column(db.DateTime, nullable=True)
    
    def is_expired(self):
        """Check if token is expired."""
        return datetime.utcnow() > self.expires_at
    
    def __repr__(self):
        return f'<RefreshToken {self.user_id}>'
