"""
Views package initialization.
"""
from app.views.auth_views import auth_bp
from app.views.totp_views import totp_bp
from app.views.password_views import password_bp
from app.views.oauth_views import oauth_bp

__all__ = ['auth_bp', 'totp_bp', 'password_bp', 'oauth_bp']
