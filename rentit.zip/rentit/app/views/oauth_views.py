"""
Google OAuth API endpoints.
"""
from flask import Blueprint, request, jsonify, redirect, url_for, make_response, current_app
from urllib.parse import quote_plus, urlparse
from app.services import GoogleOAuthService, AuthService
from logging_config import get_logger

logger = get_logger(__name__)

oauth_bp = Blueprint('oauth', __name__, url_prefix='/api/auth')


@oauth_bp.route('/google', methods=['GET'])
def google_login():
    """
    Redirect to Google OAuth authorization.
    
    Returns:
        - Redirect to Google authorization URL
    """
    try:
        auth_url = GoogleOAuthService.get_authorization_url()
        logger.info("Redirecting to Google authorization")
        return redirect(auth_url)

    except ValueError as ve:
        # Configuration issue (missing client_id or redirect uri)
        logger.error(f"Google login configuration error: {str(ve)}")
        return jsonify({'error': 'Google OAuth не настроен', 'detail': str(ve)}), 400

    except Exception as e:
        logger.error(f"Google login redirect error: {str(e)}")
        return jsonify({'error': 'Ошибка входа через Google'}), 500


@oauth_bp.route('/google/callback', methods=['GET'])
def google_callback():
    """
    Handle Google OAuth callback.
    
    Query parameters:
        - code: Authorization code from Google
        - state: State parameter for CSRF protection
    
    Returns:
        - 200: Redirects to success page with tokens
        - 400: Authorization failed
    """
    try:
        code = request.args.get('code')
        logger.info(f"Google callback received args: {request.args.to_dict()}")
        
        if not code:
            logger.warning("Google callback without authorization code")
            return jsonify({'error': 'Отсутствует код авторизации'}), 400
        
        # Exchange code for token
        success, token_data = GoogleOAuthService.exchange_code_for_token(code)
        
        if not success:
            logger.error(f"Token exchange error detail: {token_data}")
            return jsonify({'error': 'Ошибка обмена кода на токен', 'detail': token_data}), 400
        
        access_token = token_data.get('access_token')
        
        # Get user info
        success, user_data = GoogleOAuthService.get_user_info(access_token)
        
        if not success:
            return jsonify({'error': user_data}), 400
        
        # Authenticate or create user
        success, user = GoogleOAuthService.authenticate_or_create_user(user_data)
        
        if not success:
            return jsonify({'error': user}), 400
        
        # Generate JWT tokens
        tokens = AuthService.generate_tokens(user)

        logger.info(f"User authenticated via Google: {user.email}")

        # Set refresh token in a secure HttpOnly cookie and redirect to frontend
        frontend = current_app.config.get('FRONTEND_URL', 'http://localhost:3000')
        success_path = current_app.config.get('OAUTH_SUCCESS_PATH', '/')

        # Build redirect URL. Place access_token in the URL fragment so the
        # frontend SPA can read it via JavaScript (fragment is not sent to server).
        access_token = tokens.get('access_token')
        fragment = ''
        if access_token:
            # Ensure token is a string
            try:
                token_str = access_token.decode() if isinstance(access_token, bytes) else str(access_token)
            except Exception:
                token_str = str(access_token)

            fragment_items = [f"access_token={quote_plus(token_str)}"]
            expires = tokens.get('expires_in')
            if expires:
                fragment_items.append(f"expires_in={quote_plus(str(expires))}")
            fragment = '#' + '&'.join(fragment_items)

        # If the configured frontend URL points to this same server, redirect
        # directly to the server-side dashboard route (include fragment) so
        # client-side JS on the dashboard can read the access token from the
        # fragment and store it in localStorage. Otherwise, redirect to the
        # external frontend URL + success path (with fragment).
        try:
            frontend_netloc = urlparse(frontend).netloc
            server_netloc = request.host
        except Exception:
            frontend_netloc = None
            server_netloc = None

        if frontend_netloc and server_netloc and frontend_netloc == server_netloc:
            # Use the server-side dashboard route and include fragment
            redirect_target = url_for('dashboard_page', _external=True) + fragment
        else:
            redirect_target = f"{frontend.rstrip('/')}{success_path}{fragment}"
        resp = make_response(redirect(redirect_target))

        refresh_token = tokens.get('refresh_token')
        if refresh_token:
            # Determine cookie flags from config
            secure = current_app.config.get('SESSION_COOKIE_SECURE', True)
            http_only = True
            samesite = current_app.config.get('SESSION_COOKIE_SAMESITE', 'Lax')

            # Compute expiration for cookie (use refresh token lifetime)
            expires = None
            try:
                delta = current_app.config.get('JWT_REFRESH_TOKEN_EXPIRES')
                if delta:
                    from datetime import datetime
                    expires = datetime.utcnow() + delta
            except Exception:
                expires = None

            resp.set_cookie(
                'refresh_token',
                refresh_token,
                httponly=http_only,
                secure=secure,
                samesite=samesite,
                expires=expires,
                path='/'
            )

        # Optionally include the access token in fragment for SPA (not cookie)
        # Redirect target could read it from URL fragment if desired.
        return resp
        
    except Exception as e:
        logger.error(f"Google callback error: {str(e)}")
        return jsonify({'error': 'Аутентификация не удалась'}), 500
