"""
Authentication API endpoints.
Handles user registration, login, token refresh, and logout.
"""
from flask import Blueprint, request, jsonify, url_for, redirect
from flask import Blueprint, request, jsonify, url_for, redirect, make_response, current_app
from app.services import AuthService, token_required
from app.models import db, User
from datetime import datetime
from app.services.email_service import EmailService
from logging_config import get_logger
from flask import make_response, current_app

logger = get_logger(__name__)

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')


@auth_bp.route('/register', methods=['POST'])
def register():
    """
    Register a new user.
    
    Expected JSON:
    {
        "email": "user@example.com",
        "username": "username",
        "password": "SecurePassword123!",
        "first_name": "John",
        "last_name": "Doe"
    }
    
    Returns:
        - 201: User registered successfully
        - 400: Invalid input
        - 409: User already exists
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Данные не предоставлены'}), 400
        
        # Validate required fields
        required_fields = ['email', 'username', 'password']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Отсутствует обязательное поле: {field}'}), 400
        
        # Register user
        success, result = AuthService.register(
            email=data['email'],
            username=data['username'],
            password=data['password'],
            first_name=data.get('first_name'),
            last_name=data.get('last_name')
        )

        if not success:
            # Distinguish between conflict (existing user) and validation errors
            msg = str(result).lower() if result else ''
            if 'already' in msg or 'taken' in msg:
                status = 409
            else:
                status = 400
            logger.warning(f"Registration failed: {result}")
            return jsonify({'error': result}), status

        user = result

        # Build verification URL and send verification email
        try:
            verification_url = url_for('auth.verify_email', token=user.verification_token, _external=True)
            EmailService.send_verification_email(user.email, verification_url)
            logger.info(f"Verification email sent to {user.email}")
        except Exception as e:
            logger.error(f"Failed to send verification email: {str(e)}")

        return jsonify({
            'message': 'Пользователь успешно зарегистрирован. Письмо с подтверждением отправлено.',
            'user': {
                'id': user.id,
                'email': user.email,
                'username': user.username,
                'first_name': user.first_name,
                'last_name': user.last_name,
            }
        }), 201
        
    except Exception as e:
        logger.error(f"Registration endpoint error: {str(e)}")
        return jsonify({'error': 'Регистрация не удалась'}), 500


@auth_bp.route('/verify', methods=['GET'])
def verify_email():
    """Handle email verification via token.

    Query parameters:
      - token: verification token

    If token is valid, mark the user as verified and redirect to login page.
    """
    try:
        token = request.args.get('token')
        if not token:
            return jsonify({'error': 'Требуется токен'}), 400

        user = User.query.filter_by(verification_token=token).first()
        if not user:
            return jsonify({'error': 'Неверный токен'}), 400

        # Check expiry
        if user.verification_token_expires and user.verification_token_expires < datetime.utcnow():
            return jsonify({'error': 'Токен просрочен'}), 400

        user.is_verified = True
        user.verification_token = None
        user.verification_token_expires = None
        db.session.commit()

        # Redirect to login with a flag
        return redirect('/login?verified=1')

    except Exception as e:
        logger.error(f"Email verification error: {str(e)}")
        return jsonify({'error': 'Подтверждение не удалось'}), 500


@auth_bp.route('/login', methods=['POST'])
def login():
    """
    Login user.
    
    Expected JSON:
    {
        "email": "user@example.com",
        "password": "SecurePassword123!"
    }
    
    Returns:
        - 200: Login successful (returns tokens or requires TOTP)
        - 400: Invalid input
        - 401: Invalid credentials
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Требуется электронная почта и пароль'}), 400
        
        # Authenticate user
        success, result = AuthService.login(data['email'], data['password'])
        
        if not success:
            return jsonify({'error': result}), 401
        
        # Check if TOTP is required
        if isinstance(result, dict) and result.get('requires_totp'):
            resp = {
                'requires_totp': True,
                'user_id': result['user_id'],
                'message': 'Требуется подтверждение TOTP'
            }
            # Include available totp methods (if provided by AuthService)
            if result.get('totp_methods'):
                resp['totp_methods'] = result.get('totp_methods')
            return jsonify(resp), 200

        # Return tokens and set access token cookie for tracking login
        access_payload = {
            'message': 'Вход выполнен',
            'tokens': result
        }

        # Create response and set cookie
        response = make_response(jsonify(access_payload), 200)
        try:
            expires = None
            # If config provides a timedelta for access token expiry, compute max_age
            exp_delta = current_app.config.get('JWT_ACCESS_TOKEN_EXPIRES')
            if hasattr(exp_delta, 'total_seconds'):
                max_age = int(exp_delta.total_seconds())
                expires = max_age
            else:
                expires = None

            cookie_name = current_app.config.get('ACCESS_TOKEN_COOKIE_NAME', 'rentit_access_token')
            # In debug mode allow non-secure cookie so it works on http://localhost
            default_secure = not bool(current_app.debug)
            secure = bool(current_app.config.get('SESSION_COOKIE_SECURE', default_secure))
            samesite = current_app.config.get('SESSION_COOKIE_SAMESITE', 'Lax')

            # Set HttpOnly cookie with access token for tracking (not used in Authorization header)
            response.set_cookie(
                cookie_name,
                result.get('access_token'),
                max_age=expires,
                secure=secure,
                httponly=True,
                samesite=samesite,
                path='/'
            )
        except Exception:
            # If cookie fails to set for any reason, continue without blocking login
            pass

        return response
        
    except Exception as e:
        logger.error(f"Login endpoint error: {str(e)}")
        return jsonify({'error': 'Ошибка входа'}), 500


@auth_bp.route('/refresh', methods=['POST'])
def refresh():
    """
    Refresh access token using refresh token.
    
    Expected JSON:
    {
        "refresh_token": "token_string"
    }
    
    Returns:
        - 200: New tokens generated
        - 401: Invalid or expired refresh token
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('refresh_token'):
            return jsonify({'error': 'Требуется refresh-токен'}), 400
        
        success, result = AuthService.refresh_tokens(data['refresh_token'])
        
        if not success:
            return jsonify({'error': result}), 401
        
        return jsonify({
            'message': 'Токены успешно обновлены',
            'tokens': result
        }), 200
        
    except Exception as e:
        logger.error(f"Token refresh endpoint error: {str(e)}")
        return jsonify({'error': 'Обновление токенов не удалось'}), 500


@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout():
    """
    Logout user (revoke refresh token).
    
    Expected JSON:
    {
        "refresh_token": "token_string"
    }
    
    Returns:
        - 200: Logged out successfully
        - 400: Missing refresh token
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('refresh_token'):
            return jsonify({'error': 'Требуется refresh-токен'}), 400
        
        success = AuthService.revoke_token(data['refresh_token'])
        
        if not success:
            return jsonify({'error': 'Не удалось отозвать токен'}), 400

        # Clear access token cookie as part of logout
        try:
            cookie_name = current_app.config.get('ACCESS_TOKEN_COOKIE_NAME', 'rentit_access_token')
            response = make_response(jsonify({'message': 'Выход выполнен успешно'}), 200)
            # Overwrite cookie to expire immediately
            response.set_cookie(cookie_name, '', max_age=0, expires=0, path='/', httponly=True)
            return response
        except Exception:
            return jsonify({'message': 'Выход выполнен успешно'}), 200
        
    except Exception as e:
        logger.error(f"Logout endpoint error: {str(e)}")
        return jsonify({'error': 'Ошибка выхода'}), 500


@auth_bp.route('/profile', methods=['GET'])
@token_required
def get_profile():
    """
    Get current user profile.
    
    Returns:
        - 200: User profile
        - 404: User not found
    """
    try:
        user = User.query.get(request.user_id)
        
        if not user:
            return jsonify({'error': 'Пользователь не найден'}), 404
        
        return jsonify({
            'user': {
                'id': user.id,
                'email': user.email,
                'username': user.username,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'is_active': user.is_active,
                'is_verified': user.is_verified,
                'totp_enabled': user.totp_enabled,
                'totp_type': user.totp_type,
                'created_at': user.created_at.isoformat(),
                'last_login': user.last_login.isoformat() if user.last_login else None,
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Get profile endpoint error: {str(e)}")
        return jsonify({'error': 'Не удалось получить профиль'}), 500


@auth_bp.route('/change-password', methods=['POST'])
@token_required
def change_password():
    """
    Change password for authenticated user.
    
    Expected JSON:
    {
        "new_password": "NewSecurePassword123!"
    }
    
    Returns:
        - 200: Password changed successfully
        - 400: Invalid input
        - 404: User not found
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('new_password'):
            return jsonify({'error': 'Требуется новый пароль'}), 400
        
        new_password = data['new_password']
        
        # Get user
        user = User.query.get(request.user_id)
        
        if not user:
            return jsonify({'error': 'Пользователь не найден'}), 404
        
        # Update password
        user.set_password(new_password)
        db.session.commit()
        
        logger.info(f"Password changed for user: {user.email}")
        
        return jsonify({'message': 'Пароль успешно изменён'}), 200
        
    except Exception as e:
        logger.error(f"Change password endpoint error: {str(e)}")
        return jsonify({'error': 'Не удалось изменить пароль'}), 500
