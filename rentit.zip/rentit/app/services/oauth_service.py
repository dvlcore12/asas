"""
Google OAuth service module.
Handles Google authentication integration.
"""
import requests
from urllib.parse import urlencode
from flask import current_app, url_for
from app.models import db, User
from logging_config import get_logger

logger = get_logger(__name__)


class GoogleOAuthService:
    """Service for Google OAuth operations."""
    
    GOOGLE_OAUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth'
    GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token'
    GOOGLE_USER_INFO_URL = 'https://www.googleapis.com/oauth2/v2/userinfo'
    
    @staticmethod
    def get_authorization_url():
        """
        Generate Google OAuth authorization URL.
        
        Returns:
            str: Authorization URL
        """
        client_id = current_app.config.get('GOOGLE_CLIENT_ID')
        redirect_uri = current_app.config.get('GOOGLE_REDIRECT_URI')

        # Validate configuration
        if not client_id:
            logger.error("Google OAuth attempted but GOOGLE_CLIENT_ID is not configured")
            raise ValueError('GOOGLE_CLIENT_ID is not configured')

        if not redirect_uri:
            logger.error("Google OAuth attempted but GOOGLE_REDIRECT_URI is not configured")
            raise ValueError('GOOGLE_REDIRECT_URI is not configured')

        params = {
            'client_id': client_id,
            'redirect_uri': redirect_uri,
            'response_type': 'code',
            'scope': 'openid profile email',
            'access_type': 'offline',
        }

        query_string = urlencode(params)
        url = f'{GoogleOAuthService.GOOGLE_OAUTH_URL}?{query_string}'

        logger.info("Generated Google OAuth authorization URL")
        return url
    
    @staticmethod
    def exchange_code_for_token(code):
        """
        Exchange authorization code for access token.
        
        Args:
            code: Authorization code from Google
            
        Returns:
            tuple (success, token_data or error_message)
        """
        try:
            data = {
                'code': code,
                'client_id': current_app.config.get('GOOGLE_CLIENT_ID'),
                'client_secret': current_app.config.get('GOOGLE_CLIENT_SECRET'),
                'redirect_uri': current_app.config.get('GOOGLE_REDIRECT_URI'),
                'grant_type': 'authorization_code',
            }
            
            response = requests.post(GoogleOAuthService.GOOGLE_TOKEN_URL, data=data)
            
            if response.status_code != 200:
                logger.error(f"Token exchange failed: {response.status_code} {response.text}")
                # Return the response body so callers can surface the provider error
                return False, response.text
            
            logger.info("Token exchange successful")
            return True, response.json()
            
        except Exception as e:
            logger.error(f"Token exchange error: {str(e)}")
            return False, str(e)
    
    @staticmethod
    def get_user_info(access_token):
        """
        Get user information from Google.
        
        Args:
            access_token: Google access token
            
        Returns:
            tuple (success, user_data or error_message)
        """
        try:
            headers = {'Authorization': f'Bearer {access_token}'}
            response = requests.get(GoogleOAuthService.GOOGLE_USER_INFO_URL, headers=headers)
            
            if response.status_code != 200:
                logger.error(f"Failed to get user info: {response.text}")
                return False, "Failed to get user information"
            
            logger.info("User info retrieved from Google")
            return True, response.json()
            
        except Exception as e:
            logger.error(f"Get user info error: {str(e)}")
            return False, str(e)
    
    @staticmethod
    def authenticate_or_create_user(google_user_data):
        """
        Authenticate or create user from Google data.
        
        Args:
            google_user_data: User data from Google
            
        Returns:
            tuple (success, user or error_message)
        """
        try:
            google_id = google_user_data.get('id')
            email = google_user_data.get('email')
            name = google_user_data.get('name', '')
            picture = google_user_data.get('picture', '')
            
            if not google_id or not email:
                logger.warning("Missing required Google user data")
                return False, "Missing required user data"
            
            # Check if user exists by Google ID
            user = User.query.filter_by(google_id=google_id).first()
            
            if user:
                # Update user info
                user.google_email = email
                user.last_login = db.func.now()
                logger.info(f"Existing user authenticated via Google: {email}")
            else:
                # Check if user exists by email
                user = User.query.filter_by(email=email).first()
                
                if user:
                    # Link Google account to existing user
                    user.google_id = google_id
                    user.google_email = email
                    logger.info(f"Google account linked to existing user: {email}")
                else:
                    # Create new user
                    username = email.split('@')[0]
                    
                    # Ensure unique username
                    counter = 1
                    original_username = username
                    while User.query.filter_by(username=username).first():
                        username = f"{original_username}{counter}"
                        counter += 1
                    
                    user = User(
                        email=email,
                        username=username,
                        google_id=google_id,
                        google_email=email,
                        first_name=name.split()[0] if name else '',
                        last_name=' '.join(name.split()[1:]) if ' ' in name else '',
                        is_verified=True,  # Email is verified by Google
                        is_active=True,
                    )
                    
                    db.session.add(user)
                    logger.info(f"New user created via Google OAuth: {email}")
            
            db.session.commit()
            return True, user
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Google authentication error: {str(e)}")
            return False, str(e)
