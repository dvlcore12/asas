"""Test sending email using EmailService.

Usage:
  $env:PYTHONPATH = 'C:\Users\Admin\Documents\rentit'
  python scripts\test_send_email.py

The script will attempt to send a test email to the address in MAIL_USERNAME
(or to TEST_EMAIL env var if set). It uses the smtplib path by default.
"""
import os
from app import create_app
from app.services.email_service import EmailService

app = create_app()

with app.app_context():
    recipient = os.getenv('TEST_EMAIL') or app.config.get('MAIL_USERNAME')
    if not recipient:
        print('No recipient configured. Set TEST_EMAIL or MAIL_USERNAME in .env')
    else:
        subject = 'RentIT test email'
        body = 'This is a test email from RentIT.'
        html = '<p>This is a <strong>test</strong> email from RentIT.</p>'

        success, msg = EmailService.send_email(recipient, subject, body, html, prefer_smtplib=True)
        print('Success:', success)
        print('Message:', msg)
