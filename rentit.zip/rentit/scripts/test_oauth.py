from app import create_app
from app.services.oauth_service import GoogleOAuthService

app = create_app()

with app.app_context():
    try:
        url = GoogleOAuthService.get_authorization_url()
        print('AUTH_URL:', url)
    except Exception as e:
        print('ERROR:', type(e).__name__, str(e))
