"""
Диагностический скрипт для проверки конфигурации email и отправки тестовых кодов.

Usage:
  $env:PYTHONPATH = 'c:\Users\Admin\Documents\rentit'
  python scripts/diagnose_email.py
"""
import os
import sys
import dotenv

# Загрузить переменные из .env
dotenv_path = os.path.join(os.path.dirname(__file__), '..', '.env')
dotenv.load_dotenv(dotenv_path)

def check_env_config():
    """Проверить конфигурацию переменных окружения."""
    print("=" * 60)
    print("ДИАГНОСТИКА EMAIL КОНФИГУРАЦИИ")
    print("=" * 60)
    print()
    
    vars_to_check = {
        'MAIL_SERVER': 'SMTP сервер',
        'MAIL_PORT': 'SMTP порт',
        'MAIL_USE_TLS': 'Использовать TLS',
        'MAIL_USERNAME': 'Учетные данные (email)',
        'MAIL_PASSWORD': 'Пароль приложения',
        'MAIL_DEFAULT_SENDER': 'Email отправителя',
    }
    
    print("📋 Переменные окружения:")
    print("-" * 60)
    
    all_configured = True
    for var, description in vars_to_check.items():
        value = os.getenv(var, 'НЕ УСТАНОВЛЕНО')
        
        if value == 'НЕ УСТАНОВЛЕНО':
            status = "❌"
            all_configured = False
        elif var == 'MAIL_PASSWORD':
            # Скрыть пароль в выводе
            status = "✅" if len(value) > 0 else "❌"
            value = "*" * len(value)
        else:
            status = "✅"
        
        print(f"{status} {description:30s}: {value}")
    
    print()
    print("=" * 60)
    
    if not all_configured:
        print("⚠️  ВНИМАНИЕ: Не все переменные окружения настроены!")
        print()
        print("📝 РЕШЕНИЕ:")
        print("1. Отредактируйте файл .env в корне проекта")
        print("2. Установите MAIL_USERNAME и MAIL_PASSWORD")
        print("3. Для Gmail используйте App Password:")
        print("   https://myaccount.google.com/apppasswords")
        print()
        return False
    else:
        print("✅ Все переменные окружения настроены!")
        return True


def test_email_sending():
    """Тестировать отправку email."""
    print()
    print("=" * 60)
    print("ТЕСТ ОТПРАВКИ EMAIL")
    print("=" * 60)
    print()
    
    try:
        from app import create_app
        from app.services.email_service import EmailService
        
        print("✅ Приложение Flask загружено")
        
        app = create_app()
        
        with app.app_context():
            recipient = os.getenv('MAIL_USERNAME')
            
            if not recipient:
                print("❌ MAIL_USERNAME не установлен")
                return False
            
            print(f"📧 Тестовая отправка на: {recipient}")
            print()
            
            subject = "RentIT: Test Email"
            body = "Test code: 123456"
            html = "<h2>Test Code</h2><p>123456</p>"
            
            # Попытка отправки
            print("⏳ Отправка письма...")
            success, msg = EmailService.send_email(
                recipient, 
                subject, 
                body, 
                html,
                prefer_smtplib=True
            )
            
            print()
            if success:
                print("✅ УСПЕШНО! Email отправлен")
                print(f"   Статус: {msg}")
                return True
            else:
                print("❌ ОШИБКА при отправке email")
                print(f"   Сообщение: {msg}")
                print()
                print("🔍 ВОЗМОЖНЫЕ ПРИЧИНЫ:")
                print("1. Неправильный пароль приложения")
                print("2. Проблема с подключением SMTP сервера")
                print("3. Проблема с интернет соединением")
                print("4. Email не активирован в Google Account")
                return False
                
    except Exception as e:
        print(f"❌ КРИТИЧЕСКАЯ ОШИБКА: {str(e)}")
        print()
        import traceback
        traceback.print_exc()
        return False


def main():
    """Главная функция диагностики."""
    try:
        print()
        
        # Шаг 1: Проверка конфигурации
        config_ok = check_env_config()
        
        if config_ok:
            # Шаг 2: Тестирование отправки
            test_email_sending()
        else:
            print()
            print("⛔ Диагностика остановлена.")
            print("   Сначала настройте переменные окружения в файле .env")
        
        print()
        print("=" * 60)
        print("📖 Подробное руководство в файле: EMAIL_SETUP_GUIDE.md")
        print("=" * 60)
        
    except Exception as e:
        print(f"❌ Ошибка: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
