"""
Tests for TOTP service.
"""
import pytest
from app.models import db, User, TOTPSettings
from app.services import TOTPService


def test_totp_secret_generation():
    """Test TOTP secret generation."""
    secret = TOTPService.generate_secret()
    
    assert secret
    assert len(secret) > 0
    # Should be base32 encoded
    assert all(c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567' for c in secret)


def test_totp_provisioning_uri():
    """Test provisioning URI generation."""
    secret = TOTPService.generate_secret()
    uri = TOTPService.get_totp_provisioning_uri(secret, 'test@example.com')
    
    assert uri
    assert 'totp' in uri.lower()
    assert 'test@example.com' in uri
    assert 'RentIT' in uri


def test_totp_code_verification():
    """Test TOTP code verification."""
    import pyotp
    
    secret = TOTPService.generate_secret()
    totp = pyotp.TOTP(secret)
    code = totp.now()
    
    # Verify current code
    assert TOTPService.verify_totp(secret, code)
    
    # Verify with invalid code
    assert not TOTPService.verify_totp(secret, '000000')


def test_backup_codes_generation():
    """Test backup codes generation."""
    codes = TOTPService.generate_backup_codes(5)
    
    assert len(codes) == 5
    assert all(isinstance(code, str) for code in codes)
    assert len(set(codes)) == 5  # All unique


def test_setup_email_totp(app_context, test_user):
    """Test email TOTP setup."""
    success, result = TOTPService.setup_email_totp(test_user.id)
    
    # In test environment, email sending will fail due to no SMTP
    # But the setup should still work
    # This test verifies the logic, not actual email sending
    assert isinstance(success, bool)


def test_setup_app_totp(app_context, test_user):
    """Test app TOTP setup."""
    success, setup_data = TOTPService.setup_app_totp(test_user.id)
    
    assert success
    assert 'secret' in setup_data
    assert 'qr_code' in setup_data
    assert 'backup_codes' in setup_data
    assert 'provisioning_uri' in setup_data
    
    # Check backup codes
    assert len(setup_data['backup_codes']) == 10


def test_verify_app_totp(app_context, test_user):
    """Test app TOTP verification."""
    import pyotp
    
    # Setup TOTP first
    success, setup_data = TOTPService.setup_app_totp(test_user.id)
    assert success
    
    secret = setup_data['secret']
    totp = pyotp.TOTP(secret)
    code = totp.now()
    
    # Verify
    success, msg = TOTPService.verify_app_totp(test_user.id, code)
    
    assert success
    assert 'verified' in msg.lower()
    
    # Check user is updated
    user = User.query.get(test_user.id)
    assert user.totp_enabled
    assert user.totp_type == 'app'


def test_disable_totp(app_context, test_user):
    """Test disabling TOTP."""
    # Setup first
    success, _ = TOTPService.setup_app_totp(test_user.id)
    assert success
    
    # Disable
    success, msg = TOTPService.disable_totp(test_user.id)
    
    assert success
    
    # Check user is updated
    user = User.query.get(test_user.id)
    assert not user.totp_enabled
    assert user.totp_settings is None
