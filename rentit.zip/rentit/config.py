"""
Configuration module for RentIT application.
Handles environment-specific settings.
"""
import os
import secrets
from datetime import timedelta


class Config:
    """Base configuration."""
    # Server Configuration
    SERVER_HOST=0.0.0.0
    SERVER_IP=146.185.211.106
    SERVER_PORT=443
    URL_SCHEME=https
    SERVER_DOMAIN=api.example.com
    
    # Database
    SQLALCHEMY_DATABASE_URI = os.getenv(
        'DATABASE_URL',
        'sqlite:///rentit.db'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # JWT Configuration
    # Generate a secure secret if not provided via environment.
    # In production you should set `JWT_SECRET_KEY` in the environment
    # so it persists across restarts. This generator provides a safe
    # default for local development.
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY') or secrets.token_urlsafe(64)
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)
    
    # Email Configuration
    MAIL_SERVER = os.getenv('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.getenv('MAIL_PORT', 587))
    # Parse MAIL_USE_TLS from environment: accept '1','true','yes' (case-insensitive)
    _mail_use_tls_raw = os.getenv('MAIL_USE_TLS', 'True')
    MAIL_USE_TLS = str(_mail_use_tls_raw).lower() in ('1', 'true', 'yes')
    MAIL_USERNAME = os.getenv('MAIL_USERNAME', 'dv320kl@gmail.com')
    MAIL_PASSWORD = os.getenv('MAIL_PASSWORD', 'pewuplofhvksummc')  # Must be set via environment variable or .env file
    MAIL_DEFAULT_SENDER = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@lirili-larila.ru')
    
    # TOTP Configuration
    TOTP_ISSUER = 'RentIT'
    TOTP_WINDOW = 1  # Allow codes within +/- 1 time window
    
    # Google OAuth Configuration
    GOOGLE_CLIENT_ID = os.getenv('GOOGLE_CLIENT_ID', '864999375534-vla9j97sph1e074ee16h03mukeaehj6r.apps.googleusercontent.com')
    GOOGLE_CLIENT_SECRET = os.getenv('GOOGLE_CLIENT_SECRET', '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')
    
    # Build GOOGLE_REDIRECT_URI from server domain if not explicitly set
    _google_redirect_uri_env = os.getenv('GOOGLE_REDIRECT_URI')
    if _google_redirect_uri_env:
        GOOGLE_REDIRECT_URI = _google_redirect_uri_env
    else:
        _scheme = os.getenv('URL_SCHEME', 'http')
        _domain = os.getenv('SERVER_DOMAIN', 'localhost:5000')
        GOOGLE_REDIRECT_URI = f"{_scheme}://{_domain}/api/auth/google/callback"
    
    # Frontend URL to redirect users to after OAuth login
    _frontend_url_env = os.getenv('FRONTEND_URL')
    if _frontend_url_env:
        FRONTEND_URL = _frontend_url_env
    else:
        _scheme = os.getenv('URL_SCHEME', 'http')
        _domain = os.getenv('SERVER_DOMAIN', 'localhost:5000')
        FRONTEND_URL = f"{_scheme}://{_domain}"
    
    # Path on the frontend (or backend) to land on after successful OAuth.
    # Default points to the server-side dashboard so users land in their account.
    OAUTH_SUCCESS_PATH = os.getenv('OAUTH_SUCCESS_PATH', '/dashboard')
    
    # Security
    PASSWORD_MIN_LENGTH = 8
    PASSWORD_REQUIRE_UPPERCASE = True
    PASSWORD_REQUIRE_NUMBERS = True
    PASSWORD_REQUIRE_SPECIAL = True
    
    # Session
    SESSION_COOKIE_SECURE = False
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Logging
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = 'logs/rentit.log'
    LOG_MAX_SIZE = 10485760  # 10MB
    LOG_BACKUP_COUNT = 5


class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    TESTING = False
    SESSION_COOKIE_SECURE = False


class ProductionConfig(Config):
    """Production configuration."""
    DEBUG = False
    TESTING = False
    SESSION_COOKIE_SECURE = True


class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    JWT_SECRET_KEY = 'test-secret-key'
    PASSWORD_MIN_LENGTH = 4  # Allow shorter passwords for tests


def get_config():
    """Get configuration based on environment."""
    env = os.getenv('FLASK_ENV', 'development')
    
    configs = {
        'development': DevelopmentConfig,
        'production': ProductionConfig,
        'testing': TestingConfig,
    }
    
    return configs.get(env, DevelopmentConfig)
