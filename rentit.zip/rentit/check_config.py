#!/usr/bin/env python
"""
Configuration validator for RentIT application.
Helps verify that your .env file is correctly configured.
"""
import os
import sys

def check_config():
    """Check and display the current configuration."""
    # Add project root to path
    sys.path.insert(0, os.path.dirname(__file__))
    
    try:
        from config import Config
        
        print("\n" + "="*60)
        print("  RentIT Configuration Validator")
        print("="*60 + "\n")
        
        # Check server configuration
        print("SERVER CONFIGURATION:")
        print(f"  SERVER_HOST:     {Config.SERVER_HOST}")
        print(f"  SERVER_IP:       {Config.SERVER_IP}")
        print(f"  SERVER_PORT:     {Config.SERVER_PORT}")
        print(f"  URL_SCHEME:      {Config.URL_SCHEME}")
        print(f"  SERVER_DOMAIN:   {Config.SERVER_DOMAIN}")
        
        # Check generated URLs
        print("\nGENERATED URLs:")
        print(f"  FRONTEND_URL:         {Config.FRONTEND_URL}")
        print(f"  GOOGLE_REDIRECT_URI:  {Config.GOOGLE_REDIRECT_URI}")
        
        # Check database
        print("\nDATABASE CONFIGURATION:")
        db_uri = Config.SQLALCHEMY_DATABASE_URI
        if "://" in db_uri:
            db_type = db_uri.split("://")[0]
            if db_type == "sqlite":
                db_display = "SQLite (local file)"
            elif db_type == "postgresql":
                db_display = "PostgreSQL"
            elif db_type == "mysql":
                db_display = "MySQL"
            else:
                db_display = db_type.upper()
        else:
            db_display = db_uri
        print(f"  Database Type:   {db_display}")
        
        # Check email configuration
        print("\nEMAIL CONFIGURATION:")
        print(f"  MAIL_SERVER:     {Config.MAIL_SERVER}")
        print(f"  MAIL_PORT:       {Config.MAIL_PORT}")
        print(f"  MAIL_USE_TLS:    {Config.MAIL_USE_TLS}")
        print(f"  MAIL_SENDER:     {Config.MAIL_DEFAULT_SENDER}")
        
        # Check OAuth configuration
        print("\nGOOGLE OAUTH CONFIGURATION:")
        client_id = Config.GOOGLE_CLIENT_ID
        if len(client_id) > 20:
            client_id = client_id[:10] + "..." + client_id[-10:]
        print(f"  GOOGLE_CLIENT_ID:     {client_id}")
        print(f"  Has Client Secret:    {'Yes' if Config.GOOGLE_CLIENT_SECRET else 'No'}")
        
        # Verify important settings
        print("\nCONFIGURATION VERIFICATION:")
        checks = []
        
        # Check SERVER_DOMAIN contains port or is a domain
        if ":" in Config.SERVER_DOMAIN or "." in Config.SERVER_DOMAIN or Config.SERVER_DOMAIN == "localhost":
            checks.append(("SERVER_DOMAIN format", "OK"))
        else:
            checks.append(("SERVER_DOMAIN format", "WARNING - no port specified"))
        
        # Check URL_SCHEME is valid
        if Config.URL_SCHEME in ["http", "https"]:
            checks.append(("URL_SCHEME", "OK"))
        else:
            checks.append(("URL_SCHEME", "ERROR - must be 'http' or 'https'"))
        
        # Check port is valid
        if 1 <= Config.SERVER_PORT <= 65535:
            checks.append(("SERVER_PORT", "OK"))
        else:
            checks.append(("SERVER_PORT", "ERROR - must be between 1 and 65535"))
        
        # Check Google OAuth URI format
        if Config.GOOGLE_REDIRECT_URI.startswith("http"):
            checks.append(("GOOGLE_REDIRECT_URI format", "OK"))
        else:
            checks.append(("GOOGLE_REDIRECT_URI format", "ERROR"))
        
        for check_name, status in checks:
            status_marker = "[OK]" if "OK" in status else "[!]" if "WARNING" in status else "[X]"
            print(f"  {status_marker} {check_name}: {status}")
        
        # Print full URL examples
        print("\nAPPLICATION URLS:")
        app_url = f"{Config.URL_SCHEME}://{Config.SERVER_DOMAIN}"
        print(f"  Main Application:    {app_url}")
        print(f"  OAuth Callback:      {Config.GOOGLE_REDIRECT_URI}")
        print(f"  Frontend URL:        {Config.FRONTEND_URL}")
        
        print("\n" + "="*60)
        print("Configuration check complete!")
        print("="*60 + "\n")
        
        return True
        
    except Exception as e:
        print(f"\nERROR: Failed to load configuration")
        print(f"Details: {str(e)}")
        print("\nMake sure .env file exists in the project root")
        return False


if __name__ == "__main__":
    success = check_config()
    sys.exit(0 if success else 1)
