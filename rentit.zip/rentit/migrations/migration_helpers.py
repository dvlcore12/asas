"""
Database migration helpers.
Use for creating schema migrations and version control.
"""

# SQLAlchemy models are defined in app/models/__init__.py
# Tables are automatically created when the app starts (db.create_all())

# For production, consider using Alembic for more advanced migrations:
# pip install alembic
# alembic init migrations
# alembic revision --autogenerate -m "Description"
# alembic upgrade head

# Manual migration script example:

"""
from app import create_app
from app.models import db

def init_db():
    '''Initialize database with all tables'''
    app = create_app()
    with app.app_context():
        db.create_all()
        print("Database initialized successfully")

def drop_db():
    '''Drop all tables (WARNING: deletes all data)'''
    app = create_app()
    with app.app_context():
        db.drop_all()
        print("Database dropped successfully")

def reset_db():
    '''Reset database (drop and recreate)'''
    drop_db()
    init_db()
    print("Database reset successfully")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == 'init':
            init_db()
        elif command == 'drop':
            drop_db()
        elif command == 'reset':
            reset_db()
        else:
            print("Unknown command")
    else:
        print("Usage: python manage.py [init|drop|reset]")
"""
